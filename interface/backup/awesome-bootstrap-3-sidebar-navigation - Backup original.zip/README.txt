A Pen created at CodePen.io. You can find this one at http://codepen.io/fmaiabatista/pen/QGxzpQ.

 Original snippet by [maridlcrmn](http://bootsnipp.com/maridlcrmn)
Converted to Less, and given a dark theme.